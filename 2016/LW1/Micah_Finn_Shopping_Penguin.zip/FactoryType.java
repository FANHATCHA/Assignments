/**
 * Micah Stairs and Finn Lidbetter
 * Shopping Penguin
 * COMP 3721
 * Dr. Ricker
 * November 21, 2016
 **/

public enum FactoryType {
  LOLLIPOPS,
  SLIPPERS;
}