/*
 * @author William Fiset, Finn Lidbetter
 * Lightning week 2 project
 * Object Oriented Design - COMP 3721
 */

public class FranklinTree extends Tree {

  public FranklinTree(int age, int pollenQuantity, boolean inBloom) {
    super("Franklin Tree", age, pollenQuantity, inBloom);
  }
  
}

