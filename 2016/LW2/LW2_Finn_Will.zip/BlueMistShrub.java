/*
 * @author William Fiset, Finn Lidbetter
 * Lightning week 2 project
 * Object Oriented Design - COMP 3721
 */

public class BlueMistShrub extends Tree {

  public BlueMistShrub (int age, int pollenQuantity, boolean inBloom) {
    super( "BlueMistShrub", age, pollenQuantity, inBloom );
  }

}
