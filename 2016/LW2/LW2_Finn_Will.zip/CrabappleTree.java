/*
 * @author William Fiset, Finn Lidbetter
 * Lightning week 2 project
 * Object Oriented Design - COMP 3721
 */

public class CrabappleTree extends Tree {
  public CrabappleTree(int age, int pollenQuantity, boolean inBloom) {
    super("CrabappleTree", age, pollenQuantity, inBloom);
  }
}