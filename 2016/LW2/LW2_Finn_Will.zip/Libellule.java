/*
 * @author William Fiset, Finn Lidbetter
 * Lightning week 2 project
 * Object Oriented Design - COMP 3721
 */

public class Libellule extends Beast {
  public Libellule (String name) {
    super(name);
  }
}
